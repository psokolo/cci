from .calc import calculate_score, check_codes_exact, check_codes_startswith
